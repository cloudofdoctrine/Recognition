# TireDefectDetection

Using some CNN methods to detect tire defects.
